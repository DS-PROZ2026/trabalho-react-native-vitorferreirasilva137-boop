import React, { useState } from 'react';
// 1. IMPORTAMOS O COMPONENTE IMAGE AQUI:
import { View, Text, TouchableOpacity, ActivityIndicator, StyleSheet, Image } from 'react-native';
const QUIZ = [

{
id: 1,
pergunta: 'Em qual clube europeu Cristiano Ronaldo marcou o seu primeiro gol oficial na famosa Liga dos Campeões?',
opcoes: ['Manchester United', 'Sporting CP', 'Real Madrid'],
respostaCerta: 0,
imagem: 'https://pdimagemecarreira.com/wp-content/uploads/2017/11/140999-gestao-de-carreira-saiba-o-que-cristiano-ronaldo-pode-nos-ensinar.jpg'
},

{
id: 2,
pergunta: 'Em 2010, o Inter de Milão conquistou a "Tríplice Coroa" (Serie A, Coppa Italia e Liga dos Campeões). Quem foi o treinador responsável?',
opcoes: ['Roberto Mancini', 'Carlo Ancelotti', 'José Mourinho'],
respostaCerta: 2,
imagem:'https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/FC_Internazionale_Milano_2021.svg/1280px-FC_Internazionale_Milano_2021.svg.png'
},

{
id: 3,
pergunta: 'Quem foi o primeiro (e único) jogador africano a vencer a Bola de Ouro da FIFA (Ballon d’Or)?',
opcoes: ['Samuel Eto’o', 'George Weah', 'Didier Drogba'],
respostaCerta: 1,
imagem:'https://africadosul.org.br/wp-content/uploads/2022/07/D_NQ_NP_748637-MLB31734865373_082019-O.jpg'
},

{
id: 4,
pergunta: ('Qual o Time Brasileiro com mais títulos do Campeonato Mundial de Clubes?'),
opcoes: ['Gremio', 'São paulo', 'Santos'],
respostaCerta: 1,
imagem:'https://upload.wikimedia.org/wikipedia/pt/3/3c/Copa_do_Mundo_de_Clubes_da_FIFA_2023_logo.png'
},

{
id: 5,
pergunta: ('Qual time com mais títulos da Libertadores?'),
opcoes: ['Boca junior', 'River plate', 'Independete'],
respostaCerta: 2,
imagem:'https://upload.wikimedia.org/wikipedia/pt/thumb/9/95/Conmebol_Libertadores_logo.svg/1280px-Conmebol_Libertadores_logo.svg.png'
},

{
id: 6,
pergunta: ('Qual é o clube com mais champions league?'),
opcoes: ['Real madrid', 'Barcelona', 'Bayer de munique '],
respostaCerta: 0,
imagem:'https://i.pinimg.com/originals/de/7b/ce/de7bce17e99f0a8af03ad9379c1d7078.png'
},

{
id: 7,
pergunta: ('Qual jogador é o maior artilheiro da história do Barcelona?'),
opcoes: ['Suarez', 'Lionel messi', 'Ronaldinho gaúcho '],
respostaCerta:1,
imagem:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTjlM_INQiBhL9L9hmsD0k9C8hm1iDI2o-eiA&s'
},

{
id: 8,
pergunta: ('A Eredivisie é o principal campeonato de qual país?'),
opcoes: ['Holanda', 'Austria', ' Russia'],
respostaCerta:0,
imagem:'https://upload.wikimedia.org/wikipedia/pt/3/3d/Eredivisie_logo.svg.png'
},

{
id: 9,
pergunta: ('Qual é o maior campeão do Brasileirão Série A?'),
opcoes: ['Palmeiras', 'Cruzeiro', ' Flamengo'],
respostaCerta:0,
imagem:'https://images.seeklogo.com/logo-png/38/1/campeonato-brasileiro-serie-a-logo-png_seeklogo-384072.png'
},

{
id: 10,
pergunta: ('Quais seleções têm 4 títulos da Copa do Mundo?'),
opcoes: ['Italia e Brasil', 'Brasil e Alemanha', 'Alemanha e Italia '],
respostaCerta:2,
imagem:'https://www.shutterstock.com/image-vector/official-fifa-world-cup-2026-260nw-2696081649.jpg'
},

];
export default function AppQuiz() {
const [telaAtual, setTelaAtual] = useState('inicio');
const [perguntaAtual, setPerguntaAtual] = useState(0);
const [pontuacao, setPontuacao] = useState(0);
const [carregando, setCarregando] = useState(false);

function iniciarJogo() {
setPerguntaAtual(0);
setPontuacao(0);
setTelaAtual('quiz');
}

function voltarAoInicio() {
setTelaAtual('inicio');
}
function responder(indiceClicado) {
setCarregando(true);
setTimeout(() => {
const pergunta = QUIZ[perguntaAtual];
if (indiceClicado === pergunta.respostaCerta) {
setPontuacao(pontuacao + 1);
}
if (perguntaAtual + 1 < QUIZ.length) {
setPerguntaAtual(perguntaAtual + 1);
} else {
setTelaAtual('resultado');
}
setCarregando(false);
}, 1500);
}
// ==========================================
// AS TELAS
// ==========================================
if (telaAtual === 'inicio') {
return (
<View style={styles.telaCentrada}>
{/* 2. EXEMPLO PRÁTICO DE IMAGEM: */}
{/* Repare nas chaves duplas {{ }} usadas para passar o link da internet */}
<Image
source={{ uri: 'https://likebol.com/wp-content/uploads/2025/11/Artigo_LikeBOL_Fundamentos-do-Futebol.webp' }}
style={styles.logoInicial}
/>
<Text style={styles.tituloPrincipal}>Quiz de Futebol</Text>
<Text style={styles.subtituloInicio}>Teste seus conhecimentos em Futebol!</Text>
<TouchableOpacity style={styles.botaoIniciar} onPress={iniciarJogo} activeOpacity={0.8}>
<Text style={styles.textoBotaoIniciar}>INICIAR JOGO</Text>
</TouchableOpacity>
</View>
);
}
if (telaAtual === 'resultado') {
return (
<View style={styles.telaCentrada}>
<Text style={styles.iconeGrande}> </Text>
<Text style={styles.titulo}>Fim de Jogo!</Text>
<Text style={styles.subtitulo}>Você acertou {pontuacao} de {QUIZ.length} perguntas.</Text>
<TouchableOpacity style={styles.botaoAcao} onPress={voltarAoInicio} activeOpacity={0.8}>
<Text style={styles.textoBotaoAcao}>Voltar ao Início</Text>
</TouchableOpacity>
</View>
);
}
if (carregando) {
return (
<View style={styles.telaCentrada}>
<ActivityIndicator size="large" color="#3b82f6" />
<Text style={styles.textoCarregando}>Validando resposta...</Text>
</View>
);
}
const pergunta = QUIZ[perguntaAtual];
return (
<View style={styles.tela}>
<View style={styles.cabecalho}>
<Text style={styles.progresso}>Pergunta {perguntaAtual + 1} de {QUIZ.length}</Text>
<Text style={styles.pontos}>Pontos: {pontuacao}</Text>
</View>
<View style={styles.cartaoPergunta}>
<Text style={styles.textoPergunta}>{pergunta.pergunta}</Text>
</View>
<View style={styles.areaOpcoes}>
{pergunta.opcoes.map((opcao, index) => (
<TouchableOpacity
key={index}
style={styles.botaoOpcao}
onPress={() => responder(index)}
activeOpacity={0.7}
>
<Text style={styles.textoOpcao}>{opcao}</Text>
</TouchableOpacity>
))}
</View>
</View>
);
}
// ==========================================
// ESTILOS
// ==========================================
const styles = StyleSheet.create({
tela: { flex: 1, backgroundColor: '#f8fafc', padding: 20, paddingTop: 60 },
telaCentrada: { flex: 1, backgroundColor: '#f8fafc', justifyContent: 'center', alignItems: 'center', padding: 20 },
// 3. ESTILO DA IMAGEM

logoInicial: { width: 200, height: 200, marginBottom: 20 },
tituloPrincipal: { fontSize: 36, fontWeight: '900', color: '#1e293b', marginBottom: 10, textAlign: 'center' },

subtituloInicio: { fontSize: 16, color: '#64748b', marginBottom: 50, textAlign: 'center', paddingHorizontal: 20 },
botaoIniciar: { backgroundColor: '#10b981', paddingVertical: 20, paddingHorizontal: 40, borderRadius: 20, width: '100%', maxWidth: 300, shadowColor: '#10b981', shadowOpacity: 0.4, shadowRadius: 15, elevation: 8, alignItems: 'center' },

textoBotaoIniciar: { color: 'white', fontSize: 20, fontWeight: '900', letterSpacing: 1 },

cabecalho: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 30, paddingHorizontal: 10 },
progresso: { fontSize: 16, fontWeight: '700', color: '#64748b' },

pontos: { fontSize: 16, fontWeight: '800', color: '#3b82f6' },

cartaoPergunta: { backgroundColor: 'white', padding: 30, borderRadius: 20, marginBottom: 30, shadowColor: '#0f172a', shadowOpacity: 0.05, shadowRadius: 15, elevation: 5, minHeight: 150, justifyContent: 'center' },

textoPergunta: { fontSize: 22, fontWeight: '800', color: '#1e293b', textAlign: 'center', lineHeight: 30 },
areaOpcoes: { flex: 1 },

botaoOpcao: { backgroundColor: 'white', padding: 20, borderRadius: 15, marginBottom: 15, borderWidth: 2, borderColor: '#e2e8f0' },

textoOpcao: { fontSize: 18, color: '#334155', fontWeight: '600', textAlign: 'center' },

iconeGrande: { fontSize: 80, marginBottom: 20 },

titulo: { fontSize: 32, fontWeight: '900', color: '#0f172a', marginBottom: 10 },

subtitulo: { fontSize: 18, color: '#64748b', marginBottom: 40 },

botaoAcao: { backgroundColor: '#3b82f6', paddingVertical: 18, paddingHorizontal: 40, borderRadius: 16, width: '100%', maxWidth: 300, alignItems: 'center' },

textoBotaoAcao: { color: 'white', fontSize: 18, fontWeight: '800' },

textoCarregando: { marginTop: 20, fontSize: 18, fontWeight: '600', color: '#3b82f6' }
});